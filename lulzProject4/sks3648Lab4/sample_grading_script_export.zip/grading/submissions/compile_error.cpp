#include <stdio.h>
#include <assert.h>
void reset(void) 
void processSummarize()

void processPurchase()

void processInventory()
